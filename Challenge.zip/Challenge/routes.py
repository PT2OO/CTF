from flask import Flask, render_template, url_for, redirect, request, make_response
import requests
import forms
import advocate

from app import app
import db


@app.route('/')
@app.route('/index')
def index():
    r = make_response(render_template('index.html'))
    r.set_cookie('anonymous', 'True')
    return r

# Broken-Access-Control
# @app.route('/admin')
# def admin():    
#     if(request.cookies.get('admin') == "True"):
#         return render_template('admin.html')
#     else:
#         return render_template('403.html')

@app.route('/analyzer')
def follow_url():
    url = request.args.get('url', '')

    if "https" in url.lower():
        return render_template('analyzer-empty-state.html')

    if url:
        if (request.cookies.get('admin') == "True"):
            if "oastify.com" in url.lower() or "localhost" in url.lower() or "https" in url.lower():
                return render_template('analyzer-empty-state.html')
            else:
                requests_module = requests
                r = requests_module.get(url)
        else:
            requests_module = advocate
            validator = advocate.AddrValidator(hostname_blacklist={"*.oastify.com",})
            r = requests_module.get(url, validator=validator)
        return render_template('analyzer.html', req=r)      
    else:
        return render_template('analyzer-empty-state.html')


